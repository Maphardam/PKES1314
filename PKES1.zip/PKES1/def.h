/*
 * def.h
 *
 *  Created on: Sep 20, 2013
 *      Author: zug
 */

#ifndef DEF_H_
#define DEF_H_

#define COUNTER_CYCLE 1
#define MAX_COUNTER_VALUE 126
#define MIN_COUNTER_VALUE -127

#endif /* DEF_H_ */
